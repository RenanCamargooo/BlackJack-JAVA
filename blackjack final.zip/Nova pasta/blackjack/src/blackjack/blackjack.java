package blackjack;

import java.util.*;

public class blackjack {
	public static void main(String[] args) {
		int x, xd, y, yd;
		int total = 0;
		int totald = 0;
		String z = "";
		String zd = "";
		String opc = "";

		Scanner sc = new Scanner(System.in);

		System.out.printf("'   _      _               _        _               _'\r\n"
				+ "'  | |    | |             | |      (_)             | |'\r\n"
				+ "'  | |__  | |  __ _   ___ | | __    _   __ _   ___ | | __'\r\n"
				+ "'  | '_ \\ | | / _` | / __|| |/ /   | | / _` | / __|| |/ /'\r\n"
				+ "'  | |_) || || (_| || (__ |   <    | || (_| || (__ |   <'\r\n"
				+ "'  |_.__/ |_| \\__,_| \\___||_|\\_\\   | | \\__,_| \\___||_|\\_\\'\r\n"
				+ "'                                 _/ |'\r\n" + "'                                |__/'\r\n"
				+ "");
		while (true) {
			System.out.println(" __________________________________________________________");
			System.out.println("|__________________________________________________________|");

			System.out.println("\n                        1 - JOGAR SOLO");
			System.out.println("                        2 - JOGAR P X PC");
			System.out.println("                         3 - como jogar");
			System.out.println("                           4 - SAIR");
			opc = sc.nextLine();

			if (opc.equals("4")) {
				System.out.println(" ____       ___                         __                                    __         \r\n"
						+ "/\\  _`\\    /\\_ \\                       /\\ \\         __                       /\\ \\        \r\n"
						+ "\\ \\ \\L\\ \\  \\//\\ \\       __       ___   \\ \\ \\/'\\    /\\_\\       __       ___   \\ \\ \\/'\\    \r\n"
						+ " \\ \\  _ <'   \\ \\ \\    /'__`\\    /'___\\  \\ \\ , <    \\/\\ \\    /'__`\\    /'___\\  \\ \\ , <    \r\n"
						+ "  \\ \\ \\L\\ \\   \\_\\ \\_ /\\ \\L\\.\\_ /\\ \\__/   \\ \\ \\\\`\\   \\ \\ \\  /\\ \\L\\.\\_ /\\ \\__/   \\ \\ \\\\`\\  \r\n"
						+ "   \\ \\____/   /\\____\\\\ \\__/.\\_\\\\ \\____\\   \\ \\_\\ \\_\\ _\\ \\ \\ \\ \\__/.\\_\\\\ \\____\\   \\ \\_\\ \\_\\\r\n"
						+ "    \\/___/    \\/____/ \\/__/\\/_/ \\/____/    \\/_/\\/_//\\ \\_\\ \\ \\/__/\\/_/ \\/____/    \\/_/\\/_/\r\n"
						+ "                                                   \\ \\____/                              \r\n"
						+ "                                                    \\/___/                               ");
				System.out.println("");
				System.out.println("                                   OBRIGADO POR JOGAR");
				System.out.println("                              Agradecimentos especiais a:\n");
				System.out.println("                          Vicenzo Luigi Berteramo de Oliveira\n");
				System.out.println("                                  Renan Camargo de Souza\n");
				System.out.println("                                  Thiago Lourenço CARAI\n");
				System.out.println("                             Caique Santos Teixeira de Souza");
				System.exit(0);

			} else if (opc.equals("1")) {
				do {
					x = randomizador();
					y = pontos(x);
					z = naipe(x);
					total += y;

					if (total > 21) {
						System.out.println("Carta sorteada \n" + z + "\n\nValor " + y + "\nTotal de pontos " + total);
						System.out.println("\nDerrota\nSinto muito\n\n");
						total = 0;
						break;

					} else {
						System.out.println("Carta sorteada \n" + z + "\n\nValor " + y + "\nTotal de pontos " + total);
						System.out.println("\nQuer comprar outra carta?\nSIM(s) NÃO(n)\n\n");
						opc = sc.nextLine();
						if (opc.equals("S") || opc.equals("s")) {
							continue;
						} else if (opc.equals("N") || opc.equals("n")) {
							if (total == 21) {
								System.out.println("\n ____  ____  ____  ____  ____  ____  ____  ____  ____ \r\n"
										+ "||B ||||L ||||A ||||C ||||K ||||J ||||A ||||C ||||K ||\r\n"
										+ "||__||||__||||__||||__||||__||||__||||__||||__||||__||\r\n"
										+ "|/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\|\n1"
										+ "s\nParabens!!!\n\n");
								total = 0;
							} else if (total < 20) {
								System.out.println("\nVitoria\nParabens!!!\n\n");
								total = 0;
							}
							break;
						}
					}
				} while (total < 21);
			} else if (opc.equals("2")) {
				do {
					x = randomizador();
					xd = randomizador();
					y = pontos(x);
					yd = pontos(xd);
					z = naipe(x);
					zd = naipe(xd);
					total += y;
					totald += yd;

					if (totald > 21 && total < 21 && total != 21) {
						System.out.println("\nTotal de pontos " + total + "\n\nTotal de pontos (Dealer) " + totald);
						System.out.println("\nVitoria\nParabens!!!\n\n");
						total = 0;
						totald = 0;
						break;
					}

					if (total > 21) {
						System.out
								.println("Carta sorteada \n" + z + "\n\nValor " + y + "\nTotal de pontos " + total + "\n");
						System.out.println("Total de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
						System.out.println("\nDerrota\nSinto muito\n\n");
						total = 0;
						totald = 0;
						break;

					} else {
						System.out
								.println("Carta sorteada \n" + z + "\n\nValor " + y + "\nTotal de pontos " + total + "\n");
						System.out.println("Carta sorteada (Dealer) ???\nTotal de pontos (Dealer) ???");
						System.out.println("\nQuer comprar outra carta?\nSIM(s) NÃO(n)\n\n");
						opc = sc.nextLine();
						if (opc.equals("S") || opc.equals("s")) {
							continue;
						} else if (opc.equals("N") || opc.equals("n")) {
							if (total == totald) {
								System.out
										.println("\nTotal de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
								System.out.println("\nEmpate!!!\n\n");
								total = 0;
								totald = 0;
							} else if (total > totald && total != 21) {
								System.out
										.println("\nTotal de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
								System.out.println("\nVitoria\nParabens!!!\n\n");
								total = 0;
								totald = 0;
							} else if (total == 21 && total > totald) {
								System.out
										.println("\nTotal de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
								System.out.println("\n ____  ____  ____  ____  ____  ____  ____  ____  ____ \r\n"
										+ "||B ||||L ||||A ||||C ||||K ||||J ||||A ||||C ||||K ||\r\n"
										+ "||__||||__||||__||||__||||__||||__||||__||||__||||__||\r\n"
										+ "|/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\||/__\\|\n\nParabens!!!!\n\n");
								total = 0;
								totald = 0;
							} else if (total < totald && totald < 21) {
								System.out
										.println("\nTotal de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
								System.out.println("\nDerrota\nSinto muito\n\n");
								total = 0;
								totald = 0;
							} else if (totald > 21 && total != 21) {
								System.out
										.println("\nTotal de pontos " + total + "\nTotal de pontos (Dealer) " + totald);
								System.out.println("\nVitoria\nParabens!!!\n\n");
								total = 0;
								totald = 0;
							}
							break;
						}
					}
				} while (total < 21);
			}else if(opc.equals("3")) {
				System.out.println("+-----------------------------------------------------------------+\r\n"
						+ "|                          Como Jogar                             |\r\n"
						+ "|                                                                 |\r\n"
						+ "|    Para vencer no modo P X PC obtenha um numero maior de pontos |\r\n"
						+ "|                    que sejam menores que 21                     |\r\n"
						+ "|                                                                 |\r\n"
						+ "|   +-------------------------------------------------------+     |\r\n"
						+ "|   |                                                       |     |\r\n"
						+ "|   |                       BLACKJACK!!!!                   |     |\r\n"
						+ "|   |                                                       |     |\r\n"
						+ "|   |      O blackjack só ocorre quando o player vence      |     |\r\n"
						+ "|   |         a maquina fazendo 21 pontos exatamente        |     |\r\n"
						+ "|   |                                                       |     |\r\n"
						+ "|   +-------------------------------------------------------+     |\r\n"
						+ "|                                                                 |\r\n"
						+ "|           Caso a maquina faça mais pontos que você              |\r\n"
						+ "|                sinto muito mas você perdeu                      |\r\n"
						+ "|                                                                 |\r\n"
						+ "|                                                                 |\r\n"
						+ "|      Treine um pouco no modo solo para entender as mecanicas    |\r\n"
						+ "|                                                                 |\r\n"
						+ "+-----------------------------------------------------------------+");
			}

		}

	}

	public static int randomizador() {
		int x;
		Random random = new Random();
		x = random.nextInt(13);
		return x;
	}

	public static int pontos(int sort) {
		int valor = 0;
		switch (sort) {
		case 0:
			valor = 1;
			break;
		case 1:
			valor = 2;
			break;
		case 2:
			valor = 3;
			break;
		case 3:
			valor = 4;
			break;
		case 4:
			valor = 5;
			break;
		case 5:
			valor = 6;
			break;
		case 6:
			valor = 7;
			break;
		case 7:
			valor = 8;
			break;
		case 8:
			valor = 9;
			break;
		case 9:
			valor = 10;
			break;
		case 10:
			valor = 10;
			break;
		case 11:
			valor = 10;
			break;
		case 12:
			valor = 10;
			break;
		}
		return valor;
	}

	public static String naipe(int x) {
		String z = "";
		switch (x) {
		case 0:
			z = ".________. \r\n"
					+ "|A♠      |\r\n"
					+ "|        |\r\n"
					+ "|   ♠    |\r\n"
					+ "|        |\r\n"
					+ "|        |\r\n"
					+ "|________|";
			break;
		case 1:
			z = ".________.\r\n"
					+ "|2♠      |\r\n"
					+ "|    ♠   |\r\n"
					+ "|        |\r\n"
					+ "|        |\r\n"
					+ "|    ♠   |\r\n"
					+ "|________|";
			break;
		case 2:
			z = ".________.\r\n"
					+ "|3♠      |\r\n"
					+ "|    ♠   |\r\n"
					+ "|    ♠   |\r\n"
					+ "|    ♠   |\r\n"
					+ "|        |\r\n"
					+ "|________|";
			break;
		case 3:
			z = ".________.\r\n"
					+ "|4♠      |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|        |\r\n"
					+ "|        |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|________|";
			break;
		case 4:
			z = ".________.\r\n"
					+ "|5♠      |\r\n"
					+ "|  ♠  ♠  |\r\n"
					+ "|    ♠   |\r\n"
					+ "|  ♠  ♠  |\r\n"
					+ "|        |\r\n"
					+ "|________|";
			break;
		case 5:
			z = ".________.\r\n"
					+ "|6♠      |\r\n"
					+ "|        |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|________|";
			break;
		case 6:
			z = ".________.\r\n"
					+ "|7♠      |\r\n"
					+ "|        |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|________|";
			break;
		case 7:
			z = ".________.\r\n"
					+ "|8♠      |\r\n"
					+ "|        |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠   ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|________|";
			break;
		case 8:
			z = ".________.\r\n"
					+ "|9♠      |\r\n"
					+ "|        |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|________|";
			break;
		case 9:
			z = ".________.\r\n"
					+ "|10♠     |\r\n"
					+ "|    ♠   |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|  ♠ ♠ ♠ |\r\n"
					+ "|________|";
			break;
		case 10:
			z = ".________.\r\n"
					+ "|J♠      |\r\n"
					+ "|        |\r\n"
					+ "|   J♠   |\r\n"
					+ "|   J♠   |\r\n"
					+ "|   J♠   |\r\n"
					+ "|________|";
			break;
		case 11:
			z = ".________.\r\n"
					+ "|Q♠      |\r\n"
					+ "|        |\r\n"
					+ "|   Q♠   |\r\n"
					+ "|   Q♠   |\r\n"
					+ "|   Q♠   |\r\n"
					+ "|________|";
			break;
		case 12:
			z = ".________.\r\n"
					+ "|K♠      |\r\n"
					+ "|        |\r\n"
					+ "|   K♠   |\r\n"
					+ "|   K♠   |\r\n"
					+ "|   K♠   |\r\n"
					+ "|________|";
			break;
		}
		return z;
	}
}
