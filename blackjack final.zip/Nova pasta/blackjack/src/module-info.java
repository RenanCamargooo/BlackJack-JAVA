/**
 * 
 */
/**
 * @author vicenzo.lboliveira
 *
 */
module blackjack {
}